
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Theme setup script
const setupTheme = () => {
  // Check if user has a saved theme preference
  if (localStorage.theme === 'dark' || 
     (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
};

// Run theme setup
setupTheme();

// Watch for system preference changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
  if (!('theme' in localStorage)) {
    if (event.matches) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }
});

createRoot(document.getElementById("root")!).render(<App />);

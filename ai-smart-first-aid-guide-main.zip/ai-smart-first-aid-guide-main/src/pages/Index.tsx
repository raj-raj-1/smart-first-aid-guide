import React, { useState, useCallback } from 'react';
import { Info, Pill, AlertTriangle, HelpCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SymptomInput from '@/components/SymptomInput';
import FirstAidCard from '@/components/FirstAidCard';
import LoadingAnimation from '@/components/LoadingAnimation';
import EmergencyButton from '@/components/EmergencyButton';
import { toast } from '@/hooks/use-toast';
import { analyzeSymptoms, AiAnalysisResult } from '@/services/aiService';
import { enhancedAnalyzeSymptoms, EnhancedAiAnalysisResult } from '@/services/enhancedAiService';

const mockFirstAidData = {
  cut: {
    title: 'Cut/Laceration',
    description: 'Treatment for a minor to moderate cut or laceration',
    steps: [
      { id: 1, content: 'Wash your hands thoroughly with soap and water.' },
      { id: 2, content: 'Clean the wound with mild soap and water, rinse well.' },
      { id: 3, content: 'Apply gentle pressure with a clean cloth or bandage to stop bleeding.' },
      { id: 4, content: 'Apply an antibiotic ointment to prevent infection.' },
      { id: 5, content: 'Cover the wound with a sterile bandage.' },
      { id: 6, content: 'Seek medical attention if the wound is deep, bleeding heavily, or shows signs of infection.', isWarning: true }
    ],
    severity: 'low',
    emergencyContact: false
  },
  burn: {
    title: 'Burn',
    description: 'First aid for minor to moderate burns',
    steps: [
      { id: 1, content: 'Cool the burn with cool (not cold) running water for 10-15 minutes.' },
      { id: 2, content: 'Do not use ice, as this can damage the tissue further.' },
      { id: 3, content: 'Remove jewelry or tight items from the burned area.' },
      { id: 4, content: 'Apply a gentle moisturizer or aloe vera gel to the burn.' },
      { id: 5, content: 'Cover with a sterile, non-stick bandage.' },
      { id: 6, content: 'Do not break blisters if they form.' },
      { id: 7, content: 'Seek medical attention for burns that are larger than 3 inches, affect hands, feet, face, or genitals, or show signs of infection.', isWarning: true }
    ],
    severity: 'medium',
    emergencyContact: false
  },
  chestPain: {
    title: 'Chest Pain',
    description: 'Potential heart attack symptoms require immediate action',
    steps: [
      { id: 1, content: 'Call emergency services (911) immediately.', isWarning: true },
      { id: 2, content: 'Have the person sit down, rest, and try to remain calm.' },
      { id: 3, content: 'Loosen any tight clothing.' },
      { id: 4, content: 'If the person is not allergic to aspirin and it\'s readily available, give them one aspirin to chew (if advised by emergency services).' },
      { id: 5, content: 'If the person becomes unconscious, check for breathing and pulse. Begin CPR if necessary and if trained.' },
      { id: 6, content: 'If an automated external defibrillator (AED) is available, use it according to the device instructions.' }
    ],
    severity: 'high',
    emergencyContact: true
  },
  headache: {
    title: 'Headache',
    description: 'First aid for common headaches',
    steps: [
      { id: 1, content: 'Rest in a quiet, dark room.' },
      { id: 2, content: 'Place a cool cloth on your forehead.' },
      { id: 3, content: 'Drink plenty of water as dehydration can cause headaches.' },
      { id: 4, content: 'Take over-the-counter pain relievers as directed.' },
      { id: 5, content: 'Seek medical attention for severe, sudden, or unusual headaches, especially if accompanied by fever, stiff neck, confusion, or after a head injury.', isWarning: true }
    ],
    severity: 'low',
    emergencyContact: false
  },
  sprain: {
    title: 'Sprain/Strain',
    description: 'First aid for muscle or joint injuries',
    steps: [
      { id: 1, content: 'Remember RICE: Rest, Ice, Compression, Elevation.' },
      { id: 2, content: 'Rest the injured area and avoid activities that cause pain.' },
      { id: 3, content: 'Apply ice wrapped in a cloth for 15-20 minutes every 2-3 hours.' },
      { id: 4, content: 'Use a compression bandage to reduce swelling.' },
      { id: 5, content: 'Elevate the injured area above heart level when possible.' },
      { id: 6, content: 'Seek medical attention if you cannot bear weight, have severe pain, or if swelling persists.', isWarning: true }
    ],
    severity: 'medium',
    emergencyContact: false
  }
};

const Index = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [firstAidData, setFirstAidData] = useState<any>(null);
  const [aiResponse, setAiResponse] = useState<EnhancedAiAnalysisResult | null>(null);
  const [useEnhancedAi, setUseEnhancedAi] = useState<boolean>(true);

  const handleSymptomSubmit = useCallback(async (symptoms: string) => {
    setIsLoading(true);
    setFirstAidData(null);
    setAiResponse(null);
    
    try {
      if (useEnhancedAi) {
        const response = await enhancedAnalyzeSymptoms(symptoms);
        setAiResponse(response);
        
        if (response.condition && response.condition in mockFirstAidData) {
          const condition = response.condition as keyof typeof mockFirstAidData;
          setFirstAidData({
            ...mockFirstAidData[condition],
            medicationSuggestions: response.medicationSuggestions,
            additionalAdvice: response.additionalAdvice,
            followUpTimeframe: response.followUpTimeframe
          });
          
          toast({
            title: "Symptoms analyzed",
            description: `We've identified potential ${mockFirstAidData[condition].title.toLowerCase()} symptoms`,
            variant: "default",
          });
        } else {
          toast({
            title: "AI Assistant Response",
            description: "We've analyzed your symptoms and provided some guidance.",
            variant: "default",
          });
        }
      } else {
        // Standard AI model
        const response = await analyzeSymptoms(symptoms);
        // Convert AiAnalysisResult to EnhancedAiAnalysisResult
        const enhancedResponse: EnhancedAiAnalysisResult = {
          ...response,
          confidence: 0.7, // Default confidence value
          emergencyLevel: 'low', // Default emergency level
          possibleConditions: response.condition ? [
            {
              name: response.condition,
              probability: 0.7,
              description: "Based on your symptoms"
            }
          ] : undefined
        };
        
        setAiResponse(enhancedResponse);
        
        if (response.condition && response.condition in mockFirstAidData) {
          const condition = response.condition as keyof typeof mockFirstAidData;
          setFirstAidData({
            ...mockFirstAidData[condition],
            medicationSuggestions: response.medicationSuggestions
          });
          
          toast({
            title: "Symptoms analyzed",
            description: `We've identified potential ${mockFirstAidData[condition].title.toLowerCase()} symptoms`,
            variant: "default",
          });
        } else {
          toast({
            title: "AI Assistant Response",
            description: "We've analyzed your symptoms and provided some guidance.",
            variant: "default",
          });
        }
      }
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      toast({
        title: "Analysis error",
        description: "There was a problem analyzing your symptoms. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [useEnhancedAi]);

  const toggleAiModel = () => {
    setUseEnhancedAi(!useEnhancedAi);
    toast({
      title: useEnhancedAi ? "Switched to Standard AI" : "Switched to Enhanced AI",
      description: useEnhancedAi 
        ? "Now using our standard symptom analysis model" 
        : "Now using our advanced symptom analysis model for more detailed responses",
      variant: "default",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-20 container mx-auto px-4">
        <section className="py-20 flex flex-col items-center">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <div className="inline-block px-3 py-1 bg-medical-100 text-medical-800 rounded-full text-xs font-medium mb-4 animate-fade-in">
              AI-Powered First Aid
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight animate-fade-in">
              Your Personal First Aid Assistant
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 animate-fade-in-delay">
              Receive immediate first aid guidance for emergency situations.
              Simply describe your symptoms in your own words, and our AI will understand and help.
            </p>
            <button 
              onClick={toggleAiModel}
              className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-colors bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              {useEnhancedAi ? "Using Enhanced AI" : "Using Standard AI"}
            </button>
          </div>
          
          <div className="w-full max-w-2xl mx-auto mb-16">
            <SymptomInput onSubmit={handleSymptomSubmit} isLoading={isLoading} />
            <p className="text-xs text-slate-500 text-center mt-3">
              For life-threatening emergencies, call 911 immediately.
            </p>
          </div>
          
          {isLoading ? (
            <LoadingAnimation />
          ) : firstAidData ? (
            <div className="w-full max-w-2xl mx-auto">
              <FirstAidCard
                title={firstAidData.title}
                description={firstAidData.description}
                steps={firstAidData.steps}
                severity={firstAidData.severity}
                emergencyContact={firstAidData.emergencyContact}
                medicationSuggestions={firstAidData.medicationSuggestions}
                additionalAdvice={firstAidData.additionalAdvice}
                followUpTimeframe={firstAidData.followUpTimeframe}
              />
              
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => {
                    setFirstAidData(null);
                    setAiResponse(null);
                  }}
                  className="text-sm text-slate-600 hover:text-medical-600 transition-colors"
                >
                  Start a new analysis
                </button>
              </div>
            </div>
          ) : aiResponse && !aiResponse.condition ? (
            <div className="w-full max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-xl shadow-soft p-6">
              <div className="flex items-start mb-4">
                <div className="mr-3">
                  <Info className="text-medical-500" size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 dark:text-white mb-2">AI Assistant Response</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{aiResponse.advice}</p>
                </div>
              </div>
              
              {aiResponse.followUpQuestions && aiResponse.followUpQuestions.length > 0 && (
                <div className="mt-4 bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                  <h4 className="font-medium text-sm mb-3 flex items-center">
                    <HelpCircle className="text-medical-500 mr-2" size={16} />
                    To help you better, I'd like to know:
                  </h4>
                  <div className="space-y-2">
                    {aiResponse.followUpQuestions.map((question, i) => (
                      <div key={i} className="bg-white dark:bg-slate-700 p-3 rounded-md text-sm">
                        {question}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {aiResponse.possibleConditions && aiResponse.possibleConditions.length > 0 && (
                <div className="mt-4 bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                  <h4 className="font-medium text-sm mb-3 flex items-center">
                    <AlertTriangle className="text-orange-500 mr-2" size={16} />
                    Possible Conditions
                  </h4>
                  <div className="space-y-2">
                    {aiResponse.possibleConditions.map((condition, i) => (
                      <div key={i} className="text-sm">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">{condition.name}</p>
                          <span className="text-xs bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                            {Math.round(condition.probability * 100)}% match
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{condition.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {aiResponse.medicationSuggestions && aiResponse.medicationSuggestions.length > 0 && (
                <div className="mt-6 bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                  <h4 className="font-medium text-sm mb-2 flex items-center">
                    <Pill className="text-medical-500 mr-2" size={16} />
                    General Medication Information
                  </h4>
                  <div className="space-y-2">
                    {aiResponse.medicationSuggestions.map((med, i) => (
                      <div key={i} className="text-sm">
                        <p className="font-medium">{med.name}</p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">{med.dosage}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => {
                    setAiResponse(null);
                  }}
                  className="text-sm text-slate-600 hover:text-medical-600 transition-colors"
                >
                  Start a new analysis
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl animate-fade-in-delay">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-soft border border-slate-100 dark:border-slate-800">
                <div className="w-12 h-12 bg-medical-100 rounded-full flex items-center justify-center mb-4">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-medical-600">
                    <path d="M9 12H15M12 9V15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-semibold text-lg mb-2">AI Analysis</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Our system uses advanced AI to understand your symptoms, even if described casually or with typos, and provide relevant first aid guidance.
                </p>
              </div>
              
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-soft border border-slate-100 dark:border-slate-800">
                <div className="w-12 h-12 bg-medical-100 rounded-full flex items-center justify-center mb-4">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-medical-600">
                    <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M12 12H15M12 16H15M9 12H9.01M9 16H9.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-semibold text-lg mb-2">Step-by-Step Guidance</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Receive clear, easy-to-follow instructions for handling common emergency situations and injuries, written in simple, friendly language.
                </p>
              </div>
              
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-soft border border-slate-100 dark:border-slate-800">
                <div className="w-12 h-12 bg-medical-100 rounded-full flex items-center justify-center mb-4">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-medical-600">
                    <path d="M12 18V18.01M12 6V14M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-semibold text-lg mb-2">Emergency Alerts</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Critical conditions trigger immediate recommendations to contact emergency services, with the advice tailored to the severity of your situation.
                </p>
              </div>
            </div>
          )}
        </section>
      </main>
      
      <EmergencyButton />
      <Footer />
    </div>
  );
};

export default Index;

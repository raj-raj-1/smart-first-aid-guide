
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import EmergencyButton from '@/components/EmergencyButton';

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-20 container mx-auto px-4">
        <section className="py-16 max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 bg-medical-100 text-medical-800 rounded-full text-xs font-medium mb-4 animate-fade-in">
              About Our Platform
            </div>
            <h1 className="text-4xl font-bold mb-6 tracking-tight animate-fade-in">
              AI-Powered First Aid Assistance
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto animate-fade-in-delay">
              Our mission is to provide immediate, accurate first aid guidance when you need it most.
            </p>
          </div>
          
          <div className="prose prose-slate dark:prose-invert max-w-none animate-fade-in-delay">
            <h2>Our Mission</h2>
            <p>
              The First Aid AI Assistant was developed with a clear mission: to leverage artificial intelligence to provide 
              immediate, accurate first aid guidance in emergency situations. We believe that quick access to proper first 
              aid instructions can make a critical difference in emergency outcomes.
            </p>
            
            <h2>How It Works</h2>
            <p>
              Our platform uses advanced natural language processing (NLP) to analyze the symptoms you describe. The AI then 
              matches these symptoms with appropriate first aid procedures from verified medical sources. The system is designed 
              to prioritize user safety, providing clear instructions for minor injuries and emphasizing the importance of 
              seeking professional medical help for serious conditions.
            </p>
            
            <div className="bg-medical-50 dark:bg-slate-800 p-6 rounded-xl my-8">
              <h3 className="text-xl font-semibold mb-3 text-medical-800 dark:text-medical-400">Key Features</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-medical-600 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Symptom analysis using artificial intelligence</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-medical-600 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Clear, step-by-step first aid instructions</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-medical-600 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Emergency service integration for critical situations</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-medical-600 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Information sourced from trusted medical authorities</span>
                </li>
              </ul>
            </div>
            
            <h2>Our Data Sources</h2>
            <p>
              All first aid guidance provided by our platform is based on procedures and protocols established by respected 
              medical organizations, including:
            </p>
            <ul>
              <li>The American Red Cross</li>
              <li>The World Health Organization (WHO)</li>
              <li>The Centers for Disease Control and Prevention (CDC)</li>
              <li>Emergency medical services guidelines</li>
            </ul>
            <p>
              Our database is regularly updated to ensure that all guidance aligns with the latest first aid best practices.
            </p>
            
            <h2>Important Disclaimer</h2>
            <p>
              While our AI is designed to provide helpful first aid guidance, it is not a replacement for professional 
              medical care. In any emergency situation, we always recommend contacting emergency services or seeking 
              professional medical attention as soon as possible.
            </p>
            <p>
              The guidance provided by this platform is intended for informational purposes only and should be used as 
              a supplement to, not a replacement for, professional medical advice, diagnosis, or treatment.
            </p>
            
            <h2>Contact Us</h2>
            <p>
              We're committed to continuously improving our platform. If you have any questions, suggestions, or feedback, 
              please don't hesitate to reach out to us at <a href="mailto:info@firstaidai.example.com" className="text-medical-600 hover:text-medical-700">info@firstaidai.example.com</a>.
            </p>
          </div>
        </section>
      </main>
      
      <EmergencyButton />
      <Footer />
    </div>
  );
};

export default About;


import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import EmergencyButton from '@/components/EmergencyButton';

const Disclaimer = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-20 container mx-auto px-4">
        <section className="py-16 max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 bg-medical-100 text-medical-800 rounded-full text-xs font-medium mb-4 animate-fade-in">
              Medical Disclaimer
            </div>
            <h1 className="text-4xl font-bold mb-6 tracking-tight animate-fade-in">
              Important Information About Our Service
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto animate-fade-in-delay">
              Please read this disclaimer carefully before using the First Aid AI Assistant.
            </p>
          </div>
          
          <div className="prose prose-slate dark:prose-invert max-w-none animate-fade-in-delay">
            <div className="bg-emergency-light border border-emergency/20 p-6 rounded-xl my-8">
              <h2 className="text-slate-900 mt-0">Not a Substitute for Professional Medical Care</h2>
              <p className="mb-0">
                <strong>
                  The First Aid AI Assistant is designed to provide general first aid guidance only and is NOT a substitute 
                  for professional medical advice, diagnosis, or treatment. Always seek the advice of qualified healthcare 
                  providers with any questions you may have regarding a medical condition.
                </strong>
              </p>
            </div>
            
            <h3>General Information Only</h3>
            <p>
              The information provided by this application is for general informational and educational purposes only. 
              It is not intended to be comprehensive or to replace professional medical advice, diagnosis, or treatment.
            </p>
            
            <h3>Emergency Situations</h3>
            <p>
              In case of emergency, call your local emergency services (such as 911 in the United States) immediately. 
              Do not delay seeking professional medical advice or emergency assistance based on information provided by 
              this application.
            </p>
            
            <h3>No Doctor-Patient Relationship</h3>
            <p>
              Using the First Aid AI Assistant does not create a doctor-patient relationship between you and the application, 
              its developers, or any medical professionals associated with its development. The application does not practice 
              medicine and does not dispense medical advice.
            </p>
            
            <h3>AI Limitations</h3>
            <p>
              While our AI system is designed to provide relevant first aid guidance, it has limitations and may not always 
              provide complete or accurate information for all situations. The AI's responses are based on the information 
              you provide and the limited context it can process.
            </p>
            
            <h3>Individual Variations</h3>
            <p>
              Each individual's medical condition is unique. First aid procedures that may be appropriate for one person 
              may not be suitable for another due to various factors including age, pre-existing medical conditions, 
              medications, allergies, and other individual circumstances.
            </p>
            
            <h3>Accuracy of Information</h3>
            <p>
              While we strive to provide accurate and up-to-date information, we make no representations or warranties of 
              any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability 
              of the information, products, services, or related graphics contained in this application for any purpose.
            </p>
            
            <h3>Liability Limitation</h3>
            <p>
              To the maximum extent permitted by applicable law, we exclude all representations, warranties, and conditions 
              relating to our application and its use. We will not be liable for any direct, indirect, incidental, consequential, 
              or punitive damages arising from your use of, or inability to use, this application.
            </p>
            
            <h3>User Responsibility</h3>
            <p>
              By using the First Aid AI Assistant, you acknowledge and agree that you are solely responsible for any decisions 
              you make based on the information provided by this application. You should always consult with a qualified 
              healthcare professional regarding any specific medical conditions or emergencies.
            </p>
            
            <h3>Updates to This Disclaimer</h3>
            <p>
              We may update this disclaimer from time to time. The most current version will always be available within 
              the application. Your continued use of the First Aid AI Assistant after any changes indicates your acceptance 
              of the revised disclaimer.
            </p>
            
            <div className="text-center mt-12">
              <p className="font-medium">
                If you have any questions about this disclaimer, please contact us at{' '}
                <a href="mailto:legal@firstaidai.example.com" className="text-medical-600 hover:text-medical-700">
                  legal@firstaidai.example.com
                </a>
              </p>
              <p className="text-sm text-slate-500">Last updated: {new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </section>
      </main>
      
      <EmergencyButton />
      <Footer />
    </div>
  );
};

export default Disclaimer;

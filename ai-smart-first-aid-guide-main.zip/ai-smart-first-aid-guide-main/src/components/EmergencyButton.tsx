
import React from 'react';
import { Phone } from 'lucide-react';

const EmergencyButton: React.FC = () => {
  return (
    <a
      href="tel:911"
      className="fixed bottom-6 right-6 z-30 flex items-center justify-center bg-emergency text-white p-4 rounded-full shadow-lg hover:bg-emergency-dark transition-all transform hover:scale-105 active:scale-95"
      aria-label="Emergency Call"
    >
      <Phone size={24} />
    </a>
  );
};

export default EmergencyButton;


import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Send, RefreshCw, Search, Info } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

// TypeScript will automatically include the type declarations from .d.ts files
// No need to explicitly import them

interface SymptomInputProps {
  onSubmit: (symptom: string) => void;
  isLoading: boolean;
}

// Common symptom suggestions to offer user - expanded with more natural language options
const symptomSuggestions = [
  "I have a headache and feel dizzy",
  "I burned my hand on the stove",
  "I have chest pain and shortness of breath",
  "I cut my finger and it's bleeding",
  "My ankle is swollen after twisting it",
  "I have a rash and itchy skin",
  "I have a high fever and body aches",
  "My stomach hurts and I feel nauseous",
  "I think I sprained my wrist yesterday",
  "I'm having trouble breathing",
  "My throat is sore and I have a cough",
  "I've been feeling really tired lately",
  "My skin is breaking out in hives",
  "My back hurts when I bend over",
  "I've been coughing up phlegm",
  "I feel dizzy when I stand up",
  "My ears hurt and feel blocked",
  "I have pain in my joints when I move",
  "I have a ringing sound in my ears",
  "My eye is red and irritated",
  "I woke up with a sore throat",
  "I've had a headache for three days",
  "My child has a fever and rash",
  "I think I have food poisoning",
  "I'm experiencing chest pressure",
  "I've been vomiting all night",
  "I have a really bad sunburn",
  "I think I broke my finger",
  "I hit my head and feel confused",
  "I have a bad allergic reaction"
];

const SymptomInput: React.FC<SymptomInputProps> = ({ onSubmit, isLoading }) => {
  const [symptom, setSymptom] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [currentSuggestions, setCurrentSuggestions] = useState<string[]>([]);
  const [typingTimer, setTypingTimer] = useState<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionRef = useRef<HTMLDivElement>(null);

  // Randomize suggestions on mount
  useEffect(() => {
    refreshSuggestions();
  }, []);

  // Click outside handler to close suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        suggestionRef.current && 
        !suggestionRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Initialize speech recognition
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognitionAPI();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        setSymptom(transcript);
      };

      recognitionInstance.onend = () => {
        setIsRecording(false);
        toast({
          title: "Voice recording ended",
          description: "You can now edit the text or submit your symptoms.",
        });
      };

      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        setIsRecording(false);
        toast({
          title: "Voice recognition error",
          description: `Error: ${event.error}. Please try again or use text input.`,
          variant: "destructive",
        });
      };

      setRecognition(recognitionInstance);
    } else {
      // Notify on mount if voice is not supported
      console.log("Speech recognition not supported in this browser");
    }

    return () => {
      if (recognition) {
        recognition.onresult = null;
        recognition.onend = null;
        recognition.onerror = null;
        if (isRecording) {
          recognition.stop();
        }
      }
    };
  }, []);

  // Focus input when component mounts
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (symptom.trim()) {
      onSubmit(symptom);
      setSymptom('');
      // Hide suggestions after submit
      setShowSuggestions(false);
      // Analytics tracking for symptom submission (if implemented)
      console.log("Symptom submitted:", symptom);
    } else {
      toast({
        title: "Please describe your symptoms",
        description: "Tell me what's bothering you so I can help. You can type informally - I'll understand.",
        variant: "destructive",
      });
      // Show suggestions when user tries to submit empty input
      setShowSuggestions(true);
    }
  };

  const toggleRecording = () => {
    if (!recognition) {
      toast({
        title: "Voice input not supported",
        description: "Your browser doesn't support voice recognition. Please use text input instead.",
        variant: "destructive",
      });
      return;
    }

    if (isRecording) {
      recognition.stop();
      setIsRecording(false);
    } else {
      setSymptom('');
      setIsRecording(true);
      recognition.start();
      toast({
        title: "Voice recording started",
        description: "Speak clearly to describe your symptoms.",
      });
      // Hide suggestions when recording
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSymptom(suggestion);
    setShowSuggestions(false);
    if (inputRef.current) {
      inputRef.current.focus();
    }
    // Optional: Auto-submit after short delay when user selects a suggestion
    const timer = setTimeout(() => {
      onSubmit(suggestion);
    }, 300);
    setTypingTimer(timer);
  };

  const refreshSuggestions = () => {
    // Select random suggestions
    const shuffled = [...symptomSuggestions].sort(() => 0.5 - Math.random());
    setCurrentSuggestions(shuffled.slice(0, 4));
  };

  const handleFocus = () => {
    if (!symptom.trim() && !isLoading && !isRecording) {
      setShowSuggestions(true);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSymptom(value);
    
    // Clear existing timer
    if (typingTimer) {
      clearTimeout(typingTimer);
    }
    
    if (value.trim() === '') {
      setShowSuggestions(true);
    } else {
      // Hide suggestions while typing, show them after a pause
      setShowSuggestions(false);
      
      // Set new timer - after 800ms of no typing, show filtered suggestions
      const timer = setTimeout(() => {
        if (value.trim() !== '') {
          // Filter suggestions that might be relevant to what user is typing
          const filtered = symptomSuggestions.filter(
            suggestion => suggestion.toLowerCase().includes(value.toLowerCase())
          );
          if (filtered.length > 0) {
            setCurrentSuggestions(filtered.slice(0, 4));
            setShowSuggestions(true);
          }
        }
      }, 800);
      
      setTypingTimer(timer);
    }
  };

  // Clean up any timers on unmount
  useEffect(() => {
    return () => {
      if (typingTimer) {
        clearTimeout(typingTimer);
      }
    };
  }, [typingTimer]);

  return (
    <div className="w-full max-w-2xl neumorph dark:neumorph-dark rounded-2xl p-1 transition-all duration-300">
      <form onSubmit={handleSubmit} className="flex items-center">
        <button
          type="button"
          className={`p-3 rounded-xl transition-colors ${
            isRecording
              ? 'text-emergency bg-emergency-light/50 dark:bg-emergency-light/20'
              : 'text-slate-500 hover:text-medical-600 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
          onClick={toggleRecording}
          disabled={isLoading}
          aria-label={isRecording ? 'Stop recording' : 'Start recording'}
        >
          {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
        </button>
        
        <div className="relative flex-1">
          <div className="flex items-center">
            <Search size={16} className="absolute left-3 text-slate-400" />
            <input
              ref={inputRef}
              type="text"
              value={symptom}
              onChange={handleChange}
              onFocus={handleFocus}
              placeholder="Describe your symptoms or emergency... (type naturally, I'll understand)"
              className="w-full p-3 pl-10 bg-transparent border-none outline-none text-foreground placeholder:text-slate-400"
              disabled={isLoading || isRecording}
            />
          </div>
          
          {showSuggestions && !isLoading && !isRecording && (
            <div 
              ref={suggestionRef}
              className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-800 rounded-lg shadow-lg z-10 border border-slate-200 dark:border-slate-700"
            >
              <div className="flex justify-between items-center p-2 border-b border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center">
                  <Info size={12} className="mr-1" />
                  Examples of what you can say
                </span>
                <button
                  type="button"
                  onClick={refreshSuggestions}
                  className="text-slate-500 hover:text-medical-600 p-1 rounded-full"
                >
                  <RefreshCw size={14} />
                </button>
              </div>
              <div className="p-1 max-h-60 overflow-y-auto">
                {currentSuggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <button
          type="submit"
          className={`p-3 rounded-xl transition-all ${
            symptom.trim()
              ? 'bg-medical-600 text-white hover:bg-medical-700'
              : 'text-slate-400 bg-slate-100 dark:bg-slate-800 cursor-not-allowed'
          }`}
          disabled={!symptom.trim() || isLoading}
          aria-label="Send"
        >
          <Send size={20} />
        </button>
      </form>
    </div>
  );
};

export default SymptomInput;

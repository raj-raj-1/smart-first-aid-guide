
import React from 'react';
import { NavLink } from 'react-router-dom';
import { HeartPulse, Info, Shield } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="mt-20 pt-10 pb-6 border-t border-slate-100 dark:border-slate-800">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <HeartPulse className="h-6 w-6 text-emergency" />
              <span className="font-semibold text-md">First Aid AI Assistant</span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 max-w-md">
              An AI-powered first aid guide designed to provide emergency assistance 
              information based on symptoms. Always seek professional medical help for 
              emergencies.
            </p>
            <div className="flex items-center space-x-2 text-sm text-slate-500 dark:text-slate-500">
              <Shield size={14} />
              <span>Not a substitute for professional medical advice</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="https://www.redcross.org/take-a-class/first-aid" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  Red Cross First Aid
                </a>
              </li>
              <li>
                <a 
                  href="https://www.who.int/emergencies" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  WHO Emergency Resources
                </a>
              </li>
              <li>
                <a 
                  href="https://www.cdc.gov/firstaid/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  CDC First Aid Guidelines
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium mb-4">Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <NavLink 
                  to="/"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink 
                  to="/about"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  About
                </NavLink>
              </li>
              <li>
                <NavLink 
                  to="/disclaimer"
                  className="text-slate-600 dark:text-slate-400 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
                >
                  Medical Disclaimer
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-slate-500 dark:text-slate-500 mb-4 md:mb-0">
            © {new Date().getFullYear()} First Aid AI Assistant. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a 
              href="#"
              className="text-xs text-slate-500 dark:text-slate-500 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
            >
              Privacy Policy
            </a>
            <a 
              href="#"
              className="text-xs text-slate-500 dark:text-slate-500 hover:text-medical-600 dark:hover:text-medical-500 transition-colors"
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import React from 'react';
import { NavLink } from 'react-router-dom';
import { HeartPulse, Info, Menu, X } from 'lucide-react';
import { useState } from 'react';
import ThemeToggle from './ThemeToggle';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed w-full top-0 z-50 glassmorphism border-b border-slate-100 dark:border-slate-800">
      <div className="container mx-auto py-4">
        <div className="flex items-center justify-between">
          <NavLink 
            to="/" 
            className="flex items-center space-x-2 transition-transform hover:scale-105"
            onClick={closeMenu}
          >
            <HeartPulse className="h-8 w-8 text-emergency" />
            <div className="flex flex-col">
              <span className="font-semibold text-lg leading-tight tracking-tight">First Aid</span>
              <span className="text-xs text-slate-600 dark:text-slate-400 leading-tight tracking-tight">AI Assistant</span>
            </div>
          </NavLink>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                `text-sm transition-colors hover:text-medical-600 ${isActive ? 'text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300'}`
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                `text-sm transition-colors hover:text-medical-600 ${isActive ? 'text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300'}`
              }
            >
              About
            </NavLink>
            <NavLink 
              to="/disclaimer" 
              className={({ isActive }) => 
                `text-sm transition-colors hover:text-medical-600 ${isActive ? 'text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300'}`
              }
            >
              Disclaimer
            </NavLink>
            <ThemeToggle />
            <a 
              href="tel:911" 
              className="bg-emergency px-4 py-2 rounded-full text-white text-sm font-medium hover:bg-emergency-dark transition-colors shadow-soft flex items-center"
            >
              Emergency Call
            </a>
          </nav>

          {/* Mobile Menu Button and Theme Toggle */}
          <div className="md:hidden flex items-center space-x-2">
            <ThemeToggle />
            <button 
              className="text-slate-700 dark:text-slate-300 hover:text-medical-600 transition-colors"
              onClick={toggleMenu}
              aria-label="Menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-[#1d2535] transition-all animate-fade-in">
          <div className="container mx-auto py-2 space-y-3">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                `block py-2 px-4 rounded-md transition-colors ${isActive ? 'bg-accent text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`
              }
              onClick={closeMenu}
            >
              Home
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                `block py-2 px-4 rounded-md transition-colors ${isActive ? 'bg-accent text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`
              }
              onClick={closeMenu}
            >
              About
            </NavLink>
            <NavLink 
              to="/disclaimer" 
              className={({ isActive }) => 
                `block py-2 px-4 rounded-md transition-colors ${isActive ? 'bg-accent text-medical-600 font-medium' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`
              }
              onClick={closeMenu}
            >
              Disclaimer
            </NavLink>
            <div className="py-2 px-4">
              <a 
                href="tel:911" 
                className="block bg-emergency px-4 py-2 rounded-full text-white text-sm font-medium text-center hover:bg-emergency-dark transition-colors shadow-soft"
              >
                Emergency Call
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

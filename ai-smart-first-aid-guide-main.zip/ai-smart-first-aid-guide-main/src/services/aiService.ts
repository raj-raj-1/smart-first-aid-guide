
// A simple mock AI service that simulates responses from an AI model
// In a real application, this would connect to OpenAI, Claude, or other LLM APIs

export interface AiAnalysisResult {
  condition: string | null;
  advice: string;
  medicationSuggestions?: MedicationSuggestion[];
  followUpQuestions?: string[]; // New field for potential follow-up questions
}

export interface MedicationSuggestion {
  name: string;
  dosage: string;
  warnings: string;
  prescription: boolean;
}

// System prompt to guide AI behavior
const SYSTEM_PROMPT = `
You are a highly intelligent AI that accurately understands and responds to all health-related messages, 
even if they have typos, slang, or incomplete sentences.

Your job is to:
1. Understand any message, even if users type informally or with mistakes
2. Think deeply and connect multiple symptoms together for analysis
3. Always respond, and if unclear, ask for more details instead of ignoring input
4. Use simple, friendly, and human-like language
5. Give useful guidance while reminding users to consult a doctor for diagnosis

Ensure every user gets a helpful and relevant response, no matter how they type their message.
`;

export const analyzeSymptoms = async (symptoms: string): Promise<AiAnalysisResult> => {
  // This is a mock implementation
  // In a real app, you would call an actual AI API here with the SYSTEM_PROMPT
  
  const symptomLower = symptoms.toLowerCase();
  
  // Normalize input text to handle typos and slang
  const normalizedSymptoms = normalizeInput(symptomLower);
  
  // Simple keyword matching to determine the condition with expanded synonyms
  const conditions = [
    { 
      name: 'cut', 
      keywords: ['cut', 'bleeding', 'laceration', 'wound', 'blood', 'knife', 'scissors', 'sharp', 'slice', 'gash', 'scratch', 'bleed', 'scrape', 'cut myself', 'bleeding from', 'slit', 'sliced', 'paper cut'] 
    },
    { 
      name: 'burn', 
      keywords: ['burn', 'hot', 'fire', 'scald', 'flame', 'steam', 'heat', 'burning', 'boiling', 'burned', 'burnt', 'scalding', 'sunburn', 'stove', 'oven', 'stinging', 'red skin', 'skin burning'] 
    },
    { 
      name: 'chestPain', 
      keywords: ['chest', 'heart', 'pain', 'pressure', 'tightness', 'discomfort', 'heaviness', 'crushing', 'squeezing', 'heartburn', 'chest hurts', 'heart attack', 'angina', 'chest feels tight', 'chest pressure', 'heart pain', 'cardiac', 'chest heavy'] 
    },
    { 
      name: 'headache', 
      keywords: ['headache', 'migraine', 'head pain', 'head', 'throbbing', 'tension', 'skull', 'head hurts', 'pounding head', 'my head', 'painful head', 'temples', 'forehead', 'head is killing me', 'head pounds', 'head ache'] 
    },
    { 
      name: 'sprain', 
      keywords: ['sprain', 'strain', 'twist', 'joint', 'ankle', 'wrist', 'muscle', 'sore', 'swollen', 'twisted', 'sprained', 'pulled muscle', 'rolled ankle', 'twisted ankle', 'hurt my ankle', 'hurt my wrist', 'swelling', 'cant move', 'twisted my'] 
    },
    { 
      name: 'soreThroat', 
      keywords: ['throat', 'sore', 'swallow', 'pain', 'scratchy', 'tonsil', 'larynx', 'pharynx', 'swollen', 'throats', 'irritated', 'throat hurts', 'difficulty swallowing'] 
    },
    { 
      name: 'stomachPain', 
      keywords: ['stomach', 'pain', 'ache', 'abdomen', 'nausea', 'belly', 'gut', 'cramp', 'bloat', 'indigestion', 'gastric', 'tummy', 'stomach hurts', 'stomach upset', 'food poisoning'] 
    },
  ];
  
  let bestMatch = '';
  let bestMatchScore = 0;
  let followUpNeeded = false;
  let followUpQuestions: string[] = [];
  
  // Find the best matching condition based on keyword frequency
  conditions.forEach(condition => {
    let matchScore = 0;
    condition.keywords.forEach(keyword => {
      if (normalizedSymptoms.includes(keyword)) {
        // Words appearing at the beginning or as whole words get higher scores
        if (normalizedSymptoms.startsWith(keyword) || 
            new RegExp(`\\b${keyword}\\b`).test(normalizedSymptoms)) {
          matchScore += 2;
        } else {
          matchScore += 1;
        }
      }
    });
    
    if (matchScore > bestMatchScore) {
      bestMatchScore = matchScore;
      bestMatch = condition.name;
    }
  });
  
  // If the input is vague or the match score is low, generate follow-up questions
  if (bestMatchScore < 2 || normalizedSymptoms.length < 10) {
    followUpNeeded = true;
    followUpQuestions = generateFollowUpQuestions(normalizedSymptoms);
  }
  
  // Generate simulated AI response based on the condition
  if (bestMatchScore > 0) {
    const result = getMockResponse(bestMatch);
    
    // Add follow-up questions if needed
    if (followUpNeeded) {
      result.followUpQuestions = followUpQuestions;
    }
    
    return result;
  }
  
  // No match found - generic response with follow-up questions
  return {
    condition: null,
    advice: "I'm not entirely sure what symptoms you're describing. Could you provide more details about what you're experiencing? For example, where is the pain or discomfort located, when did it start, and how severe is it?",
    medicationSuggestions: [],
    followUpQuestions: [
      "Where are you experiencing symptoms?",
      "When did these symptoms start?",
      "Is there any pain, and if so, how would you rate it from 1-10?",
      "Have you noticed any other symptoms alongside this?",
      "Does anything make your symptoms better or worse?"
    ]
  };
};

// Helper function to normalize input text (handle typos, slang, etc.)
function normalizeInput(text: string): string {
  // Replace common typos and informal language
  const normalizations: {[key: string]: string} = {
    'headake': 'headache',
    'miagraine': 'migraine',
    'migrane': 'migraine',
    'chest pain': 'chestpain',
    'heart burn': 'heartburn',
    'cant breath': 'cant breathe',
    'cant move': 'cant move',
    'hurts': 'pain',
    'ache': 'pain',
    'burning': 'burn',
    'cut open': 'cut',
    'bleeding': 'blood',
    'tummy': 'stomach',
    'belly': 'stomach',
    'feeling sick': 'nausea',
    'throwing up': 'vomit',
    'not feeling good': 'sick',
    'sore throat': 'throat sore',
    'throat hurts': 'throat pain',
    'cant swallow': 'difficulty swallowing'
  };
  
  let normalized = text;
  
  // Apply normalizations
  Object.entries(normalizations).forEach(([key, value]) => {
    normalized = normalized.replace(new RegExp(key, 'g'), value);
  });
  
  return normalized;
}

// Generate contextual follow-up questions based on the input
function generateFollowUpQuestions(text: string): string[] {
  const baseQuestions = [
    "Could you describe where exactly you're feeling this?",
    "When did these symptoms start?",
    "On a scale of 1-10, how would you rate any pain you're experiencing?"
  ];
  
  const specificQuestions: {[key: string]: string} = {
    'head': "Does the head pain feel like pressure, throbbing, or sharp pain?",
    'chest': "Does the chest discomfort get worse when you take a deep breath or lie down?",
    'breath': "Are you having any difficulty breathing along with your symptoms?",
    'cut': "How deep is the cut and is it still bleeding?",
    'burn': "What caused the burn and how much area does it cover?",
    'fever': "Do you know what your temperature is?",
    'stomach': "Is the stomach pain constant or does it come and go?",
    'dizzy': "Does the dizziness occur when you stand up or change positions?",
    'rash': "Is the rash itchy, painful, or neither?",
    'throat': "Is swallowing painful or difficult?",
    'back': "Does the back pain radiate to your legs or other areas?",
    'joint': "Is the joint swollen, red, or warm to the touch?",
    'cough': "Is your cough dry or are you coughing up anything?"
  };
  
  const questions = [...baseQuestions];
  
  // Add specific questions based on keywords in the text
  Object.entries(specificQuestions).forEach(([keyword, question]) => {
    if (text.includes(keyword) && questions.length < 5) {
      questions.push(question);
    }
  });
  
  // If we found less than 4 questions, add a general one
  if (questions.length < 4) {
    questions.push("Have you tried any remedies or medications for your symptoms so far?");
  }
  
  return questions;
}

// Mock response data for different conditions
const getMockResponse = (condition: string): AiAnalysisResult => {
  switch (condition) {
    case 'cut':
      return {
        condition: 'cut',
        advice: "It sounds like you're dealing with a cut. First, apply gentle pressure with a clean cloth to stop any bleeding. Once the bleeding slows, rinse the wound with clean water and apply a thin layer of antibiotic ointment if available. Cover with a clean bandage. If the cut is deep, very large, or won't stop bleeding, please seek medical attention right away.",
        medicationSuggestions: [
          {
            name: "Neosporin or similar antibiotic ointment",
            dosage: "Apply a thin layer to the affected area 1-3 times daily",
            warnings: "Stop use if rash or irritation occurs. Not for deep puncture wounds or serious burns.",
            prescription: false
          },
          {
            name: "Over-the-counter pain reliever (acetaminophen/Tylenol)",
            dosage: "Follow package instructions for dosage",
            warnings: "Do not exceed recommended dose. Consult doctor if pain persists.",
            prescription: false
          }
        ]
      };
      
    case 'burn':
      return {
        condition: 'burn',
        advice: "I understand you have a burn. First thing to do is cool the area with cool (not cold) running water for 10-15 minutes. Don't use ice directly on a burn as it can damage the skin further. After cooling, apply a gentle moisturizer like aloe vera and cover with a clean, non-stick bandage. Try not to break any blisters that form. If the burn is larger than 3 inches, appears deep, or is on your face, hands, feet, or a major joint, please seek medical attention.",
        medicationSuggestions: [
          {
            name: "Aloe vera gel",
            dosage: "Apply to affected area 2-3 times daily",
            warnings: "Discontinue if irritation occurs. For minor burns only.",
            prescription: false
          },
          {
            name: "Ibuprofen (Advil/Motrin)",
            dosage: "Follow package instructions for dosage",
            warnings: "May cause stomach irritation. Take with food.",
            prescription: false
          }
        ]
      };
      
    case 'chestPain':
      return {
        condition: 'chestPain',
        advice: "Chest pain can be a sign of something serious like a heart attack. Please call emergency services (911) immediately. While waiting, try to stay calm, sit or lie in a comfortable position, and loosen any tight clothing. If recommended by a medical professional and you're not allergic, you might take an aspirin. Remember, it's always better to be safe when experiencing chest pain.",
        medicationSuggestions: [
          {
            name: "Aspirin (if advised by emergency services)",
            dosage: "A single adult dose (typically 325mg) can be chewed if advised by emergency services",
            warnings: "Only if not allergic and if advised by medical professionals. Not suitable for children.",
            prescription: false
          }
        ]
      };
      
    case 'headache':
      return {
        condition: 'headache',
        advice: "I'm sorry to hear about your headache. Try resting in a quiet, dark room to reduce stimulation. A cool cloth on your forehead might help, and make sure you're drinking enough water as dehydration can trigger headaches. Over-the-counter pain relievers can help manage the pain. If your headache is unusually severe, came on suddenly, or is accompanied by fever, stiff neck, confusion, or followed a head injury, please seek medical attention right away.",
        medicationSuggestions: [
          {
            name: "Acetaminophen (Tylenol)",
            dosage: "Follow package instructions for dosage",
            warnings: "Do not exceed recommended dose. Consult doctor if pain persists for more than a few days.",
            prescription: false
          },
          {
            name: "Ibuprofen (Advil/Motrin)",
            dosage: "Follow package instructions for dosage",
            warnings: "May cause stomach irritation. Take with food.",
            prescription: false
          }
        ]
      };
      
    case 'sprain':
      return {
        condition: 'sprain',
        advice: "It sounds like you might have a sprain or strain. Try following the RICE method: Rest the injured area, Ice it for 15-20 minutes several times a day (with a cloth between the ice and your skin), Compress it with an elastic bandage if available, and Elevate it above the level of your heart when possible. Over-the-counter pain relievers can help with discomfort. If you can't put weight on the injury, see significant swelling or bruising, or the pain is severe, please have it checked by a healthcare provider.",
        medicationSuggestions: [
          {
            name: "Ibuprofen (Advil/Motrin)",
            dosage: "Follow package instructions for dosage",
            warnings: "May cause stomach irritation. Take with food.",
            prescription: false
          },
          {
            name: "Naproxen (Aleve)",
            dosage: "Follow package instructions for dosage",
            warnings: "May cause stomach irritation. Take with food. Not for use in children under 12 unless directed by a doctor.",
            prescription: false
          }
        ]
      };
      
    case 'soreThroat':
      return {
        condition: 'soreThroat',
        advice: "For your sore throat, try gargling with warm salt water (1/4 teaspoon salt in 8 ounces warm water) several times a day. Drinking warm liquids like tea with honey can be soothing, and throat lozenges may help with temporary relief. If the sore throat is severe, lasts longer than a week, is accompanied by a high fever, or makes it very difficult to swallow, please see a healthcare provider to rule out strep throat or other infections.",
        medicationSuggestions: [
          {
            name: "Throat lozenges (menthol or benzocaine)",
            dosage: "Dissolve one lozenge slowly in mouth as needed",
            warnings: "Do not exceed package recommendations. Not for children under 4.",
            prescription: false
          },
          {
            name: "Acetaminophen (Tylenol) or Ibuprofen (Advil)",
            dosage: "Follow package instructions for dosage",
            warnings: "For pain relief. Do not exceed recommended dose.",
            prescription: false
          }
        ]
      };
      
    case 'stomachPain':
      return {
        condition: 'stomachPain',
        advice: "For stomach pain, try resting your stomach by eating mild, easy-to-digest foods like bananas, rice, applesauce, and toast (the BRAT diet). Stay hydrated with clear fluids, taking small sips if you're nauseated. A heating pad on low setting might help with cramping. If your pain is severe, located in the lower right abdomen, accompanied by persistent vomiting, or if you see blood in your stool, seek medical attention right away.",
        medicationSuggestions: [
          {
            name: "Antacids (Tums, Rolaids)",
            dosage: "Follow package instructions",
            warnings: "For short-term use. Consult doctor if symptoms persist more than 2 weeks.",
            prescription: false
          },
          {
            name: "Bismuth subsalicylate (Pepto-Bismol)",
            dosage: "Follow package instructions",
            warnings: "May cause tongue and stool to darken. Not for use in children with chickenpox or flu symptoms.",
            prescription: false
          }
        ]
      };
      
    default:
      return {
        condition: null,
        advice: "I couldn't identify your symptoms specifically. Please provide more details or consult with a healthcare professional if you're experiencing any concerning symptoms.",
        medicationSuggestions: []
      };
  }
};

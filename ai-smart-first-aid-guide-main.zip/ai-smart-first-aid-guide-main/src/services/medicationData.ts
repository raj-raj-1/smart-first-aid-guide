
import { MedicationSuggestion } from './aiService';

// Enhanced medication database with more detailed information
export const enhancedMedicationSuggestions: Record<string, MedicationSuggestion[]> = {
  cut: [
    {
      name: "Neosporin or similar antibiotic ointment",
      dosage: "Apply a thin layer to the affected area 1-3 times daily after cleaning",
      warnings: "Stop use if rash or irritation occurs. Not for deep puncture wounds or serious burns. Seek medical attention if the wound shows signs of infection.",
      prescription: false
    },
    {
      name: "Over-the-counter pain reliever (acetaminophen/Tylenol)",
      dosage: "Adults and children 12 years and over: 2 tablets every 4-6 hours as needed; not to exceed 6 tablets in 24 hours",
      warnings: "Do not exceed recommended dose. Do not use for more than 10 days unless directed by a doctor. May cause liver damage if misused.",
      prescription: false
    },
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults and children 12 years and over: 1-2 tablets every 4-6 hours as needed; not to exceed 6 tablets in 24 hours",
      warnings: "May cause stomach irritation; take with food or milk. Do not use if you have stomach problems, kidney disease, or are taking blood thinners.",
      prescription: false
    }
  ],
  burn: [
    {
      name: "Aloe vera gel",
      dosage: "Apply to affected area 2-3 times daily or as needed for comfort",
      warnings: "Discontinue if irritation occurs. For minor burns only. Seek medical attention for severe burns or burns covering large areas.",
      prescription: false
    },
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults: 200-400mg every 4-6 hours as needed for pain and inflammation",
      warnings: "May cause stomach irritation. Take with food. Do not use for extended periods without medical supervision.",
      prescription: false
    },
    {
      name: "Hydrocortisone cream (0.5-1%)",
      dosage: "Apply a thin layer to affected area up to 3-4 times daily",
      warnings: "Only for use after the burn has cooled. Not for open wounds, deep burns, or facial burns. Discontinue if irritation increases.",
      prescription: false
    }
  ],
  chestPain: [
    {
      name: "Aspirin (if advised by emergency services)",
      dosage: "A single adult dose (typically 325mg) can be chewed if advised by emergency services",
      warnings: "Only if not allergic and if advised by medical professionals. Not suitable for children or those with bleeding disorders or stomach ulcers.",
      prescription: false
    },
    {
      name: "Nitroglycerin",
      dosage: "As prescribed by your doctor, typically 1 tablet under the tongue every 5 minutes, up to 3 doses",
      warnings: "Only use if previously prescribed for you. May cause severe headache or dizziness. Do not use with erectile dysfunction medications.",
      prescription: true
    }
  ],
  headache: [
    {
      name: "Acetaminophen (Tylenol)",
      dosage: "Adults and children 12 years and over: 2 tablets (500mg each) every 4-6 hours as needed; not to exceed 8 tablets in 24 hours",
      warnings: "Do not exceed recommended dose. Consult doctor if pain persists for more than a few days. May cause liver damage if misused.",
      prescription: false
    },
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults and children 12 years and over: 1-2 tablets (200mg each) every 4-6 hours; not to exceed 6 tablets in 24 hours",
      warnings: "May cause stomach irritation. Take with food. Consult doctor if pain persists for more than 3 days.",
      prescription: false
    },
    {
      name: "Excedrin Migraine",
      dosage: "Adults: 2 caplets with a full glass of water; maximum 2 caplets in 24 hours",
      warnings: "Contains acetaminophen, aspirin, and caffeine. Do not use with other products containing acetaminophen or with other NSAIDs. May cause stomach upset.",
      prescription: false
    }
  ],
  sprain: [
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults: 200-400mg every 4-6 hours as needed for pain and inflammation; maximum 1200mg in 24 hours",
      warnings: "May cause stomach irritation. Take with food. Do not use for more than 10 days unless directed by a doctor.",
      prescription: false
    },
    {
      name: "Naproxen (Aleve)",
      dosage: "Adults: 220mg every 8-12 hours as needed (or 440mg initially, then 220mg after 12 hours)",
      warnings: "May cause stomach irritation. Take with food. Not for use in children under 12 unless directed by a doctor.",
      prescription: false
    },
    {
      name: "Topical analgesic creams (Bengay, Icy Hot)",
      dosage: "Apply to affected area up to 3-4 times daily",
      warnings: "For external use only. Do not apply to broken skin or with heating pad. Wash hands after application.",
      prescription: false
    }
  ],
  allergicReaction: [
    {
      name: "Diphenhydramine (Benadryl)",
      dosage: "Adults and children 12 years and over: 25-50mg every 4-6 hours as needed; maximum 300mg in 24 hours",
      warnings: "May cause drowsiness. Do not drive or operate heavy machinery. Avoid alcohol.",
      prescription: false
    },
    {
      name: "Cetirizine (Zyrtec)",
      dosage: "Adults and children 6 years and over: 10mg once daily",
      warnings: "May cause mild drowsiness. Avoid alcohol. Discontinue use and consult doctor if allergic reaction persists.",
      prescription: false
    },
    {
      name: "Epinephrine auto-injector (EpiPen)",
      dosage: "Adults and children over 30kg: 0.3mg injection; Children under 30kg: 0.15mg",
      warnings: "For severe allergic reactions only. Seek immediate medical attention after use. Follow up with healthcare provider.",
      prescription: true
    }
  ],
  fever: [
    {
      name: "Acetaminophen (Tylenol)",
      dosage: "Adults and children 12 years and over: 2 tablets (500mg each) every 4-6 hours as needed; maximum 3000mg in 24 hours",
      warnings: "Do not exceed recommended dose. May cause liver damage if misused. Consult doctor for fevers lasting more than 3 days.",
      prescription: false
    },
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults and children 12 years and over: 200-400mg every 4-6 hours as needed; maximum 1200mg in 24 hours",
      warnings: "May cause stomach irritation. Take with food. Do not use in children under 6 months without doctor's advice.",
      prescription: false
    },
    {
      name: "Naproxen (Aleve)",
      dosage: "Adults and children 12 years and over: 220mg every 8-12 hours; maximum 660mg in 24 hours",
      warnings: "May cause stomach irritation. Take with food. Not recommended for children under 12 years or for extended use in adults without medical supervision.",
      prescription: false
    }
  ],
  soreThroat: [
    {
      name: "Throat lozenges (menthol/benzocaine)",
      dosage: "Adults and children over 5: Dissolve 1 lozenge slowly in mouth every 2 hours as needed",
      warnings: "Do not exceed 10 lozenges per day. Not for children under 5 years due to choking hazard.",
      prescription: false
    },
    {
      name: "Acetaminophen (Tylenol)",
      dosage: "Adults: 500-1000mg every 4-6 hours as needed; not to exceed 3000mg in 24 hours",
      warnings: "Do not exceed recommended dose. May cause liver damage if misused.",
      prescription: false
    },
    {
      name: "Ibuprofen (Advil/Motrin)",
      dosage: "Adults: 200-400mg every 4-6 hours as needed; not to exceed 1200mg in 24 hours",
      warnings: "May cause stomach irritation. Take with food.",
      prescription: false
    }
  ],
  stomachPain: [
    {
      name: "Antacids (Tums, Rolaids)",
      dosage: "Adults: 1-2 tablets as symptoms occur, up to 10 tablets per day",
      warnings: "Do not use for more than 2 weeks continuously. Consult doctor if symptoms persist.",
      prescription: false
    },
    {
      name: "Famotidine (Pepcid)",
      dosage: "Adults: 10-20mg once or twice daily",
      warnings: "Do not exceed 40mg per day. Consult doctor if symptoms persist more than 2 weeks.",
      prescription: false
    },
    {
      name: "Bismuth subsalicylate (Pepto-Bismol)",
      dosage: "Adults: 2 tablets or 2 tablespoons (30ml) every 30-60 minutes as needed, up to 8 doses in 24 hours",
      warnings: "May cause temporary darkening of tongue and stool. Do not use if allergic to aspirin. Not recommended for children with chickenpox or flu symptoms.",
      prescription: false
    }
  ]
};

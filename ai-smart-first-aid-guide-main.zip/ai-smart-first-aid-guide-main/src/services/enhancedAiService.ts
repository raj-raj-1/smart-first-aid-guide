
// Enhanced AI service that simulates a more powerful AI model for faster and more accurate responses
// In a real application, this would connect to OpenAI, Claude, or other advanced LLM APIs

import { AiAnalysisResult, MedicationSuggestion } from './aiService';

// Enhanced system prompt to guide AI behavior with more sophisticated understanding
const ENHANCED_SYSTEM_PROMPT = `
You are a highly intelligent AI that accurately understands and responds to all health-related messages, 
even if they have typos, slang, or incomplete sentences.

Your job is to:
1. Understand any message, even if users type informally or with mistakes
2. Think deeply and connect multiple symptoms together for analysis
3. Always respond, and if unclear, ask for more details instead of ignoring input
4. Use simple, friendly, and human-like language
5. Give useful guidance while reminding users to consult a doctor for diagnosis

Ensure every user gets a helpful and relevant response, no matter how they type their message.
`;

// Extended interface with more detailed analysis
export interface EnhancedAiAnalysisResult extends AiAnalysisResult {
  confidence: number;
  additionalAdvice?: string[];
  possibleConditions?: Array<{
    name: string;
    probability: number;
    description: string;
  }>;
  emergencyLevel: 'low' | 'medium' | 'high';
  followUpTimeframe?: string;
  followUpQuestions?: string[]; // Added to enhanced model as well
}

// Expanded symptom dictionary for better pattern matching and typo handling
const symptomPatterns = [
  { 
    name: 'cut',
    keywords: ['cut', 'bleeding', 'laceration', 'wound', 'blood', 'knife', 'scissors', 'sharp', 'slice', 'gash', 'scratch', 'bleed', 'scrape', 'cut myself', 'bleeding from', 'slit', 'sliced', 'paper cut', 'wound', 'injury'],
    followUpTimeframe: '7-10 days if stitches were needed, otherwise monitor for signs of infection',
    emergencyLevel: 'low',
    additionalAdvice: [
      'Elevate the affected area above heart level if possible to reduce bleeding and swelling',
      'Regularly change bandages to keep the wound clean',
      'Watch for signs of infection such as increased redness, warmth, swelling, or pus'
    ]
  },
  { 
    name: 'burn',
    keywords: ['burn', 'hot', 'fire', 'scald', 'flame', 'steam', 'heat', 'burning', 'boiling', 'burned', 'burnt', 'scalding', 'sunburn', 'stove', 'oven', 'stinging', 'red skin', 'skin burning', 'hot water', 'cooking burn'],
    followUpTimeframe: '24-48 hours for moderate burns, seek immediate care for severe burns',
    emergencyLevel: 'medium',
    additionalAdvice: [
      'Do not apply butter, oil, or ice directly to burns',
      'Cover burns with a clean, dry bandage',
      'For chemical burns, rinse the area continuously with water for at least 20 minutes'
    ]
  },
  { 
    name: 'chestPain',
    keywords: ['chest', 'heart', 'pain', 'pressure', 'tightness', 'discomfort', 'heaviness', 'crushing', 'squeezing', 'heartburn', 'chest hurts', 'heart attack', 'angina', 'chest feels tight', 'chest pressure', 'heart pain', 'cardiac', 'heart burn', 'cant breathe chest', 'chest feels heavy'],
    followUpTimeframe: 'Immediate medical attention required',
    emergencyLevel: 'high',
    additionalAdvice: [
      'If the person becomes unconscious, begin CPR if you are trained',
      'Do not drive yourself to the hospital; call for emergency services',
      'Try to stay calm and take slow, deep breaths while waiting for help'
    ]
  },
  { 
    name: 'headache',
    keywords: ['headache', 'migraine', 'head pain', 'head', 'throbbing', 'tension', 'skull', 'temple', 'forehead', 'sinus', 'head hurts', 'pounding head', 'my head', 'painful head', 'head is killing me', 'head pounds', 'bad headache', 'severe headache', 'head throbbing', 'head ache'],
    followUpTimeframe: '3-5 days if symptoms persist or worsen',
    emergencyLevel: 'low',
    additionalAdvice: [
      'Maintain a regular sleep schedule',
      'Stay hydrated throughout the day',
      'Consider tracking triggers like certain foods or stress factors'
    ]
  },
  { 
    name: 'sprain',
    keywords: ['sprain', 'strain', 'twist', 'joint', 'ankle', 'wrist', 'muscle', 'sore', 'swollen', 'twisted', 'pulled', 'sprained', 'pulled muscle', 'rolled ankle', 'twisted ankle', 'hurt my ankle', 'hurt my wrist', 'swelling', 'cant move', 'twisted my', 'rolled my', 'injured my', 'inflamed joint'],
    followUpTimeframe: '1-2 weeks for mild sprains, see a doctor if severe',
    emergencyLevel: 'medium',
    additionalAdvice: [
      'Avoid activities that cause pain for at least 48 hours',
      'Gentle stretching may help once the initial pain subsides',
      'Consider physical therapy for proper rehabilitation of moderate to severe sprains'
    ]
  },
  {
    name: 'allergicReaction',
    keywords: ['allergic', 'allergy', 'hives', 'rash', 'itchy', 'swelling', 'face', 'lips', 'throat', 'difficulty breathing', 'allergies', 'itching', 'swollen', 'cant breathe', 'allergen', 'histamine', 'reaction', 'allergic reaction', 'food allergy', 'broke out in', 'skin rash', 'itches', 'anaphylaxis'],
    followUpTimeframe: 'Immediate care for severe reactions, 24-48 hours for mild reactions',
    emergencyLevel: 'high',
    additionalAdvice: [
      'If prescribed, use an epinephrine auto-injector (like an EpiPen) for severe reactions',
      'Try to identify and avoid the allergen in the future',
      'Consider allergy testing if the cause is unknown'
    ]
  },
  {
    name: 'fever',
    keywords: ['fever', 'temperature', 'hot', 'chills', 'sweating', 'shivering', 'cold', 'flu', 'high temperature', 'warm', 'feverish', 'feel hot', 'burning up', 'night sweats', 'running a fever', 'temp', 'hot flashes', 'body hot', 'temp high'],
    followUpTimeframe: '3 days for adults, 24 hours for children under 2',
    emergencyLevel: 'medium',
    additionalAdvice: [
      'Stay hydrated by drinking plenty of fluids',
      'Use a light blanket if you have chills',
      'Seek immediate medical attention for very high fevers (above 103°F/39.4°C)'
    ]
  },
  {
    name: 'soreThroat',
    keywords: ['sore throat', 'throat pain', 'throat hurts', 'strep', 'swallowing hurts', 'painful to swallow', 'throat', 'tonsils', 'hoarse', 'voice', 'strep throat', 'throat infection', 'pharyngitis', 'laryngitis', 'scratchy throat', 'throat inflammation'],
    followUpTimeframe: '7 days if symptoms persist or worsen',
    emergencyLevel: 'low',
    additionalAdvice: [
      'Gargle with warm salt water several times a day',
      'Stay hydrated with warm (not hot) liquids',
      'Consider throat lozenges for temporary relief'
    ]
  },
  {
    name: 'stomachPain',
    keywords: ['stomach', 'pain', 'abdominal', 'ache', 'cramp', 'nausea', 'vomiting', 'diarrhea', 'bloating', 'indigestion', 'belly', 'gut', 'abdomen', 'bellyache', 'stomach hurts', 'tummy ache', 'food poisoning', 'gastric', 'gi pain', 'stomach pain', 'upset stomach', 'gastritis'],
    followUpTimeframe: '24-48 hours if symptoms persist or worsen',
    emergencyLevel: 'medium',
    additionalAdvice: [
      'Try small, bland meals like rice, toast, or bananas',
      'Stay hydrated with clear fluids like water or diluted sports drinks',
      'Avoid spicy foods, caffeine, and alcohol until symptoms improve'
    ]
  }
];

// Import the enhanced medication suggestions from a separate file to reduce file size
import { enhancedMedicationSuggestions } from './medicationData';

// Enhanced helper function to normalize input text with more patterns for typos, slang, and informal language
function normalizeInput(text: string): string {
  // Extended normalization dictionary to handle more variations, typos, and informal language
  const normalizations: {[key: string]: string} = {
    // Common medical term typos and slang
    'headake': 'headache',
    'miagraine': 'migraine',
    'migrane': 'migraine',
    'chest pain': 'chestpain',
    'heart burn': 'heartburn',
    'cant breath': 'cant breathe',
    'cant move': 'cant move',
    'hurts': 'pain',
    'ache': 'pain',
    'burning': 'burn',
    'cut open': 'cut',
    'bleeding': 'blood',
    // Added more informal terms and slang
    'feeling awful': 'sick',
    'feeling terrible': 'sick',
    'not feeling good': 'sick',
    'tummy': 'stomach',
    'belly': 'stomach',
    'head is killing me': 'headache',
    'pounding head': 'headache',
    'cant see straight': 'dizzy',
    'room spinning': 'dizzy',
    'threw up': 'vomit',
    'throwing up': 'vomit',
    'puking': 'vomit',
    'puke': 'vomit',
    'heart racing': 'heart palpitations',
    'broke my': 'fracture',
    'eye hurts': 'eye pain',
    'cant move arm': 'arm pain',
    'arm hurts': 'arm pain',
    'leg hurts': 'leg pain',
    'cant move leg': 'leg pain',
    'feel hot': 'fever',
    'burning up': 'fever',
    'scratchy throat': 'sore throat',
    'throat is killing me': 'sore throat',
    'cant swallow': 'sore throat',
    'stomach upset': 'stomach pain',
    'runs': 'diarrhea',
    'the runs': 'diarrhea',
    'barfing': 'vomit',
    'dizzie': 'dizzy',
    'dizzy spell': 'dizzy',
    'woozy': 'dizzy',
    'lightheaded': 'dizzy'
  };
  
  let normalized = text.toLowerCase();
  
  // Apply normalizations
  Object.entries(normalizations).forEach(([key, value]) => {
    normalized = normalized.replace(new RegExp(key, 'g'), value);
  });
  
  return normalized;
}

// Advanced symptom analysis with natural language processing simulation and better handling of unclear inputs
export const enhancedAnalyzeSymptoms = async (symptoms: string): Promise<EnhancedAiAnalysisResult> => {
  // Early check for empty or extremely short queries
  if (!symptoms || symptoms.trim().length < 3) {
    return {
      condition: null,
      advice: "I'm not sure what symptoms you're experiencing. Could you please describe what's bothering you? Even a few words about how you're feeling would help me provide better guidance.",
      medicationSuggestions: [],
      confidence: 0.1,
      emergencyLevel: 'low',
      followUpQuestions: [
        "Where are you experiencing discomfort or pain?",
        "When did your symptoms start?",
        "Have you noticed anything that makes your symptoms better or worse?"
      ]
    };
  }

  // Normalize and process the symptoms text
  const symptomLower = symptoms.toLowerCase();
  const normalizedSymptoms = normalizeInput(symptomLower);
  
  // Calculate keyword matches for each condition with weighted scoring
  type ConditionScore = {
    name: string;
    score: number;
    keywordMatches: string[];
    pattern: typeof symptomPatterns[0];
  };
  
  const conditionScores: ConditionScore[] = [];
  
  // Analyze symptoms against each condition pattern
  symptomPatterns.forEach(pattern => {
    let score = 0;
    const matches: string[] = [];
    
    pattern.keywords.forEach(keyword => {
      if (normalizedSymptoms.includes(keyword)) {
        // Words appearing at the beginning or as whole words get higher scores
        if (normalizedSymptoms.startsWith(keyword) || 
            new RegExp(`\\b${keyword}\\b`).test(normalizedSymptoms)) {
          score += 2;
        } else {
          score += 1;
        }
        matches.push(keyword);
      }
    });
    
    // Additional scoring for symptom combinations that strongly indicate a condition
    if (pattern.name === 'chestPain' && 
        (normalizedSymptoms.includes('chest') && 
         (normalizedSymptoms.includes('pain') || normalizedSymptoms.includes('pressure')))) {
      score += 3;
    }
    
    if (pattern.name === 'allergicReaction' && 
        (normalizedSymptoms.includes('rash') && normalizedSymptoms.includes('breathing'))) {
      score += 3;
    }
    
    if (pattern.name === 'stomachPain' && 
        (normalizedSymptoms.includes('stomach') && normalizedSymptoms.includes('pain'))) {
      score += 3;
    }
    
    if (pattern.name === 'soreThroat' && 
        (normalizedSymptoms.includes('throat') && normalizedSymptoms.includes('sore'))) {
      score += 3;
    }
    
    if (matches.length > 0) {
      conditionScores.push({
        name: pattern.name,
        score,
        keywordMatches: matches,
        pattern
      });
    }
  });
  
  // Sort by score in descending order
  conditionScores.sort((a, b) => b.score - a.score);
  
  // Enhanced algorithm to detect vague queries or low confidence
  const isVagueQuery = conditionScores.length === 0 || 
                       (conditionScores[0].score < 2) || 
                       (normalizedSymptoms.length < 10 && conditionScores.length < 2);
  
  let followUpQuestions: string[] = [];
  
  if (isVagueQuery) {
    followUpQuestions = generateContextualFollowUpQuestions(normalizedSymptoms);
  }
  
  // If no matches found or score too low, return enhanced response for vague queries
  if (conditionScores.length === 0 || conditionScores[0].score < 1) {
    return {
      condition: null,
      advice: `I notice you mentioned "${symptoms}", but I'm not entirely sure what symptoms you're describing. Could you provide more details about what you're experiencing? For example, where is the pain or discomfort located, when did it start, and how severe is it?`,
      medicationSuggestions: [],
      confidence: 0.2,
      emergencyLevel: 'low',
      followUpQuestions,
      possibleConditions: [
        { 
          name: "Unknown condition", 
          probability: 0.2, 
          description: "Based on the information provided, a specific condition couldn't be determined." 
        }
      ]
    };
  }
  
  // Best matching condition
  const bestMatch = conditionScores[0];
  const bestMatchName = bestMatch.name;
  const matchConfidence = Math.min(0.95, bestMatch.score / 10 + 0.5);
  
  // Generate alternative possible conditions based on lower scores
  const possibleConditions = conditionScores.map(condition => ({
    name: condition.name,
    probability: Math.min(0.95, condition.score / (bestMatch.score * 1.5)),
    description: `Possible ${condition.name} based on ${condition.keywordMatches.join(", ")}`
  }));
  
  // Fetch medication suggestions
  const medications = enhancedMedicationSuggestions[bestMatchName] || [];
  
  // Create the enhanced response with more detailed and personalized advice
  return {
    condition: bestMatchName,
    advice: getPersonalizedAdviceForCondition(bestMatchName, symptoms, bestMatch.pattern),
    medicationSuggestions: medications,
    confidence: matchConfidence,
    possibleConditions: possibleConditions.slice(0, 3), // Top 3 conditions
    additionalAdvice: bestMatch.pattern.additionalAdvice,
    emergencyLevel: bestMatch.pattern.emergencyLevel as 'low' | 'medium' | 'high',
    followUpTimeframe: bestMatch.pattern.followUpTimeframe,
    followUpQuestions: isVagueQuery ? followUpQuestions : undefined
  };
};

// Generate contextual follow-up questions based on the user's specific input
function generateContextualFollowUpQuestions(text: string): string[] {
  const baseQuestions = [
    "Could you describe where exactly you're feeling this?",
    "When did these symptoms start?",
    "On a scale of 1-10, how would you rate any pain you're experiencing?"
  ];
  
  const specificQuestions: {[key: string]: string} = {
    'head': "Does the head pain feel like pressure, throbbing, or sharp pain?",
    'chest': "Does the chest discomfort get worse when you take a deep breath or lie down?",
    'breath': "Are you having any difficulty breathing along with your symptoms?",
    'cut': "How deep is the cut and is it still bleeding?",
    'burn': "What caused the burn and how much area does it cover?",
    'fever': "Do you know what your temperature is?",
    'stomach': "Is the stomach pain constant or does it come and go?",
    'dizzy': "Does the dizziness occur when you stand up or change positions?",
    'rash': "Is the rash itchy, painful, or neither?",
    'back': "Does the back pain radiate to your legs or other areas?",
    'throat': "Is swallowing painful or difficult?",
    'cough': "Is your cough dry or are you coughing up anything?",
    'eye': "Do you have any changes in vision or sensitivity to light?",
    'ear': "Are you experiencing any hearing changes or ringing in the ears?",
    'leg': "Is there any swelling, redness, or warmth in the affected leg?",
    'arm': "Can you move your arm normally or is your range of motion limited?",
    'joint': "Is the joint swollen, red, or warm to the touch?",
    'blood': "How much blood have you lost? Is the bleeding controlled now?",
    'nausea': "Have you vomited or felt like you needed to?",
    'diarrhea': "How long have you had diarrhea and how often?",
    'swelling': "Is the swelling in one area or multiple areas?",
    'tired': "Did this fatigue come on suddenly or gradually?",
    'sleep': "Have you noticed any changes in your sleep patterns?"
  };
  
  const questions = [...baseQuestions];
  
  // Add specific questions based on keywords in the text
  Object.entries(specificQuestions).forEach(([keyword, question]) => {
    if (text.includes(keyword) && questions.length < 5) {
      questions.push(question);
    }
  });
  
  // If we have fewer than 4 questions, add more general ones
  if (questions.length < 4) {
    const generalFollowups = [
      "Have you tried any remedies or medications so far?",
      "Has this happened to you before?",
      "Does anyone in your family have similar symptoms?",
      "Have you recently changed your diet or daily routine?",
      "Are your symptoms worse at a particular time of day?"
    ];
    
    // Add general questions until we have 4-5 questions total
    for (let i = 0; i < generalFollowups.length && questions.length < 5; i++) {
      questions.push(generalFollowups[i]);
    }
  }
  
  return questions;
}

// Enhanced helper function to get personalized advice for a condition
function getPersonalizedAdviceForCondition(condition: string, originalInput: string, pattern: typeof symptomPatterns[0]): string {
  // Base advice templates with more natural, conversational language
  switch (condition) {
    case 'cut':
      return `Based on your description "${originalInput}", it sounds like you're dealing with a cut. First, apply gentle pressure with a clean cloth to stop any bleeding. Once the bleeding slows, rinse the wound with clean water and apply a thin layer of antibiotic ointment if available. Cover with a clean bandage. If the cut is deep, very large, or won't stop bleeding, please seek medical attention right away.`;
      
    case 'burn':
      return `From what you've described ("${originalInput}"), I understand you have a burn. The first thing to do is cool the area with cool (not cold) running water for 10-15 minutes. Don't use ice directly on a burn as it can damage the skin further. After cooling, apply a gentle moisturizer like aloe vera and cover with a clean, non-stick bandage. Try not to break any blisters that form. If the burn is larger than 3 inches, appears deep, or is on your face, hands, feet, or a major joint, please seek medical attention.`;
      
    case 'chestPain':
      return `I notice you mentioned "${originalInput}" - chest pain can be a sign of something serious like a heart attack. Please call emergency services (911) immediately. While waiting, try to stay calm, sit or lie in a comfortable position, and loosen any tight clothing. If recommended by a medical professional and you're not allergic, you might take an aspirin. Remember, it's always better to be safe when experiencing chest pain.`;
      
    case 'headache':
      return `I see you're experiencing "${originalInput}". For your headache, try resting in a quiet, dark room to reduce stimulation. A cool cloth on your forehead might help, and make sure you're drinking enough water as dehydration can trigger headaches. Over-the-counter pain relievers can help manage the pain. If your headache is unusually severe, came on suddenly, or is accompanied by fever, stiff neck, confusion, or followed a head injury, please seek medical attention right away.`;
      
    case 'sprain':
      return `Based on "${originalInput}", it sounds like you might have a sprain or strain. Try following the RICE method: Rest the injured area, Ice it for 15-20 minutes several times a day (with a cloth between the ice and your skin), Compress it with an elastic bandage if available, and Elevate it above the level of your heart when possible. Over-the-counter pain relievers can help with discomfort. If you can't put weight on the injury, see significant swelling or bruising, or the pain is severe, please have it checked by a healthcare provider.`;
      
    case 'allergicReaction':
      return `I understand from "${originalInput}" that you might be experiencing an allergic reaction. For a mild reaction with hives or rash, an over-the-counter antihistamine like Benadryl can help reduce symptoms. If you're experiencing any difficulty breathing, facial swelling, or lightheadedness, this could be a severe allergic reaction requiring immediate emergency attention. Use an epinephrine auto-injector if you have one and call 911. Try to avoid the allergen in the future if you can identify it.`;
      
    case 'fever':
      return `I see you mentioned "${originalInput}". For a fever, make sure to rest and stay hydrated by drinking plenty of fluids. You can take over-the-counter fever reducers like acetaminophen or ibuprofen according to package directions. A lukewarm (not cold) bath might also help reduce your temperature. If your fever is very high (above 103°F/39.4°C), lasts more than three days, or is accompanied by severe headache, stiff neck, confusion, or difficulty breathing, please seek medical attention right away.`;
      
    case 'soreThroat':
      return `Based on "${originalInput}", it sounds like you have a sore throat. Try gargling with warm salt water (1/4 teaspoon of salt in 8 ounces of warm water) several times a day. Stay hydrated with warm liquids like tea with honey, and consider over-the-counter throat lozenges for temporary relief. If your sore throat is severe, lasts longer than a week, or is accompanied by difficulty swallowing, high fever, or swollen glands, please see a healthcare provider to rule out strep throat or other infections.`;
      
    case 'stomachPain':
      return `I understand from "${originalInput}" that you're experiencing stomach pain. Try to rest your stomach by eating bland, easy-to-digest foods like bananas, rice, applesauce, and toast (the BRAT diet). Stay hydrated with clear fluids, but take small sips if you're nauseated. A heating pad on low setting may help with cramps. If your pain is severe, located in the lower right abdomen, accompanied by persistent vomiting, or if you see blood in your stool, seek medical attention immediately as these could be signs of a more serious condition.`;
      
    default:
      return `Based on what you've told me ("${originalInput}"), I recommend monitoring your condition. If your symptoms persist or worsen, please consult with a healthcare professional for a proper diagnosis and treatment plan. Remember that this advice is not a substitute for professional medical care.`;
  }
}

// Export other functions for potential future use or testing
export { normalizeInput, generateContextualFollowUpQuestions, getPersonalizedAdviceForCondition };

'use server';
/**
 * @fileOverview Analyzes user-provided symptoms and suggests potential conditions, first aid advice, and medicine options.
 *
 * - analyzeSymptoms - A function that takes symptom input and returns a prioritized list of potential conditions and advice.
 * - AnalyzeSymptomsInput - The input type for the analyzeSymptoms function, containing the user's symptoms.
 * - AnalyzeSymptomsOutput - The return type for the analyzeSymptoms function, providing a list of potential conditions and advice.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';
import {getConditionInfo, getMedicationInfo} from '@/services/medical-resource';

const AnalyzeSymptomsInputSchema = z.object({
  symptoms: z.string().describe('The symptoms described by the user.'),
});
export type AnalyzeSymptomsInput = z.infer<typeof AnalyzeSymptomsInputSchema>;

const AnalyzeSymptomsOutputSchema = z.object({
  conditions: z.array(
    z.object({
      conditionName: z.string().describe('The name of the potential condition.'),
      confidence: z.number().describe('A number between 0 and 1 indicating the confidence level of the condition.'),
      firstAidAdvice: z.string().describe('Relevant first aid advice for the condition.'),
      medicineRecommendations: z.array(z.string()).describe('List of recommended medicines for the condition.'),
      resourceUrl: z.string().describe('URL for more information about the condition.'),
    })
  ).describe('A prioritized list of potential conditions based on the symptoms.'),
  tips: z.array(z.string()).describe('General health tips based on the symptoms.'),
});
export type AnalyzeSymptomsOutput = z.infer<typeof AnalyzeSymptomsOutputSchema>;

export async function analyzeSymptoms(input: AnalyzeSymptomsInput): Promise<AnalyzeSymptomsOutput> {
  return analyzeSymptomsFlow(input);
}

const getConditionInfoTool = ai.defineTool({
  name: 'getConditionInfo',
  description: 'Retrieves information about a medical condition, including a URL for more details.',
  inputSchema: z.object({
    conditionName: z.string().describe('The name of the condition to look up.'),
  }),
  outputSchema: z.object({
    conditionName: z.string().describe('The name of the condition.'),
    resourceUrl: z.string().describe('A URL providing more information about the condition.'),
  }),
},
async input => {
  return getConditionInfo(input.conditionName);
}
);

const getMedicationInfoTool = ai.defineTool({
  name: 'getMedicationInfo',
  description: 'Retrieves information about a medication, including a URL for more details.',
  inputSchema: z.object({
    medicationName: z.string().describe('The name of the medication to look up.'),
  }),
  outputSchema: z.object({
    medicationName: z.string().describe('The name of the medication.'),
    resourceUrl: z.string().describe('A URL providing more information about the medication.'),
  }),
},
async input => {
  return getMedicationInfo(input.medicationName);
}
);

const analyzeSymptomsPrompt = ai.definePrompt({
  name: 'analyzeSymptomsPrompt',
  tools: [getConditionInfoTool, getMedicationInfoTool],
  input: {
    schema: z.object({
      symptoms: z.string().describe('The symptoms described by the user.'),
    }),
  },
  output: {
    schema: AnalyzeSymptomsOutputSchema,
  },
  prompt: `You are a smart first aid guide. A user will provide you with their symptoms, and you will provide a prioritized list of potential conditions, first aid advice, medicine options, and tips.

Analyze the symptoms provided by the user. Identify potential medical conditions that could be causing these symptoms. Provide a confidence level (0-1) for each condition, indicating how likely it is to be the correct diagnosis.

For each potential condition, suggest relevant first aid measures that the user can take immediately. Also, recommend over-the-counter medications that might help alleviate the symptoms.

Finally, offer general health tips that are relevant to the user's symptoms.

Please format your response as a JSON object that adheres to the AnalyzeSymptomsOutputSchema.

Here are the symptoms provided by the user: {{{symptoms}}}
`,
});

const analyzeSymptomsFlow = ai.defineFlow<
  typeof AnalyzeSymptomsInputSchema,
  typeof AnalyzeSymptomsOutputSchema
>({
  name: 'analyzeSymptomsFlow',
  inputSchema: AnalyzeSymptomsInputSchema,
  outputSchema: AnalyzeSymptomsOutputSchema,
}, async input => {
  const {output} = await analyzeSymptomsPrompt(input);

  // Optionally enrich the output by calling the tool to get more information.
  if (output?.conditions) {
    for (const condition of output.conditions) {
      try {
        const conditionInfo = await getConditionInfoTool({conditionName: condition.conditionName});
        condition.resourceUrl = conditionInfo ? conditionInfo.resourceUrl : "";
      } catch (e) {
        console.error(`Failed to get condition info for ${condition.conditionName}: ${e}`);
        condition.resourceUrl = "";
      }

      // Ensure resourceUrl is always a string
      condition.resourceUrl = condition.resourceUrl || "";
    }
  }

  return output!;
});

'use server';

/**
 * @fileOverview Summarizes medical information for a given condition or medication.
 *
 * - summarizeMedicalInfo - A function that summarizes medical information.
 * - SummarizeMedicalInfoInput - The input type for the summarizeMedicalInfo function.
 * - SummarizeMedicalInfoOutput - The return type for the summarizeMedicalInfo function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';
import {getConditionInfo, getMedicationInfo} from '@/services/medical-resource';

const SummarizeMedicalInfoInputSchema = z.object({
  query: z.string().describe('The medical condition or medication to summarize information about.'),
});
export type SummarizeMedicalInfoInput = z.infer<typeof SummarizeMedicalInfoInputSchema>;

const SummarizeMedicalInfoOutputSchema = z.object({
  summary: z.string().describe('A summary of the medical information.'),
});
export type SummarizeMedicalInfoOutput = z.infer<typeof SummarizeMedicalInfoOutputSchema>;

export async function summarizeMedicalInfo(input: SummarizeMedicalInfoInput): Promise<SummarizeMedicalInfoOutput> {
  return summarizeMedicalInfoFlow(input);
}

const getMedicalInfoTool = ai.defineTool({
  name: 'getMedicalInfo',
  description: 'Retrieves information about a medical condition or medication and returns a URL with further reading.',
  inputSchema: z.object({
    query: z.string().describe('The medical condition or medication to get information about.'),
  }),
  outputSchema: z.object({
    conditionName: z.string().describe('The name of the condition or medication.'),
    resourceUrl: z.string().describe('A URL providing more information about the condition or medication.'),
  }),
  async implementation(input) {
    // Attempt to retrieve condition info, and if not found, attempt to retrieve medication info
    try {
      const conditionInfo = await getConditionInfo(input.query);
      return {
        conditionName: conditionInfo.conditionName,
        resourceUrl: conditionInfo.resourceUrl,
      };
    } catch (e) {
      try {
        const medicationInfo = await getMedicationInfo(input.query);
        return {
          conditionName: medicationInfo.medicationName,
          resourceUrl: medicationInfo.resourceUrl,
        };
      } catch (e) {
        return {
          conditionName: `No information found for ${input.query}`,
          resourceUrl: '',
        };
      }
    }
  },
});

const prompt = ai.definePrompt({
  name: 'summarizeMedicalInfoPrompt',
  tools: [getMedicalInfoTool],
  input: {
    schema: z.object({
      query: z.string().describe('The medical condition or medication to summarize information about.'),
    }),
  },
  output: {
    schema: z.object({
      summary: z.string().describe('A summary of the medical information.'),
    }),
  },
  prompt: `You are a medical information summarization expert. The user will provide a query, which is the name of a medical condition or medication.  You must use the getMedicalInfo tool to retrieve information about the condition or medication.  Then provide a summary of the information.

Query: {{{query}}}

If no information is found for the query, then return 'No information found'.`,
});

const summarizeMedicalInfoFlow = ai.defineFlow<
  typeof SummarizeMedicalInfoInputSchema,
  typeof SummarizeMedicalInfoOutputSchema
>({
  name: 'summarizeMedicalInfoFlow',
  inputSchema: SummarizeMedicalInfoInputSchema,
  outputSchema: SummarizeMedicalInfoOutputSchema,
},
async input => {
  const {output} = await prompt(input);
  return output!;
});

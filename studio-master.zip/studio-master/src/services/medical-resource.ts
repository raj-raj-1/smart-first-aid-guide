/**
 * Represents information about a medical condition.
 */
export interface ConditionInfo {
  /**
   * The name of the condition.
   */
  conditionName: string;
  /**
   * A URL providing more information about the condition.
   */
  resourceUrl: string;
}

/**
 * Asynchronously retrieves information about a medical condition.
 *
 * @param conditionName The name of the condition to look up.
 * @returns A promise that resolves to a ConditionInfo object.
 */
export async function getConditionInfo(conditionName: string): Promise<ConditionInfo> {
  // TODO: Implement this by calling an API.
    // Basic NLP: convert to lowercase and replace spaces with hyphens
    const processedConditionName = conditionName.toLowerCase().replace(/ /g, '-');

  return {
    conditionName: conditionName,
    resourceUrl: 'https://www.mayoclinic.org/diseases-conditions/' + processedConditionName
  };
}

/**
 * Represents information about a medication.
 */
export interface MedicationInfo {
  /**
   * The name of the medication.
   */
  medicationName: string;
  /**
   * A URL providing more information about the medication.
   */
  resourceUrl: string;
}

/**
 * Asynchronously retrieves information about a medication.
 *
 * @param medicationName The name of the medication to look up.
 * @returns A promise that resolves to a MedicationInfo object.
 */
export async function getMedicationInfo(medicationName: string): Promise<MedicationInfo> {
  // TODO: Implement this by calling an API.
    const processedMedicationName = medicationName.toLowerCase().replace(/ /g, '-');

  return {
    medicationName: medicationName,
    resourceUrl: 'https://www.webmd.com/drugs/2/drug-' + processedMedicationName + '-details'
  };
}

'use client';

import {useState, useEffect} from 'react';
import {analyzeSymptoms, AnalyzeSymptomsOutput} from '@/ai/flows/analyze-symptoms';
import {Button} from '@/components/ui/button';
import {Textarea} from '@/components/ui/textarea';
import {Card, CardContent, CardDescription, CardHeader, CardTitle} from '@/components/ui/card';
import Image from 'next/image';
import {useTheme} from 'next-themes';
import {SunIcon, MoonIcon, PhoneCall} from 'lucide-react';
import {AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger} from '@/components/ui/alert-dialog';
import {Toaster} from '@/components/ui/toaster';

function useSymptomAnalysis() {
  const [symptoms, setSymptoms] = useState('');
  const [analysis, setAnalysis] = useState<AnalyzeSymptomsOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const analyze = async () => {
    setIsLoading(true);
    try {
      const result = await analyzeSymptoms({symptoms});
      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing symptoms:', error);
      // Handle error appropriately, e.g., display an error message to the user
    } finally {
      setIsLoading(false);
    }
  };

  return {
    symptoms,
    setSymptoms,
    analysis,
    analyze,
    isLoading,
  };
}

export default function Home() {
  const {symptoms, setSymptoms, analysis, analyze, isLoading} = useSymptomAnalysis();
  const {theme, setTheme} = useTheme();

  // Automatically analyze when the component mounts
  useEffect(() => {
    if (symptoms) {
      analyze();
    }
  }, []);

  return (
    <div className="relative min-h-screen bg-background">
      {/* Background Image */}
      <Image
        src="https://images.unsplash.com/photo-1532938314562-3a575b99a329?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2864&q=80"
        alt="Health and Wellness"
        layout="fill"
        objectFit="cover"
        className="absolute inset-0 opacity-30 dark:opacity-40 z-0"
      />

      <div className="relative z-10 container mx-auto p-4 text-foreground">
        {/* Theme Toggler */}
        <div className="absolute top-4 right-4 flex items-center space-x-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          >
            {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>

        <h1 className="text-3xl font-bold mb-4 text-center">HealthWise Assistant</h1>

        {/* Symptom Input */}
        <div className="mb-4">
          <Textarea
            placeholder="Enter your symptoms here..."
            value={symptoms}
            onChange={(e) => setSymptoms(e.target.value)}
            className="w-full mb-2"
          />
          <Button onClick={analyze} disabled={isLoading} className="bg-accent text-white">
            {isLoading ? 'Analyzing...' : 'Analyze Symptoms'}
          </Button>
        </div>

        {/* Emergency Call Button */}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">
              <PhoneCall className="mr-2 h-4 w-4" /> Emergency Call (108)
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action will initiate an emergency call. Please proceed only if it's a real emergency.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => window.location.href = 'tel:108'}>
                Call Emergency
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Suggestion Display */}
        {analysis && (
          <div>
            <h2 className="text-2xl font-semibold mb-2">Suggestions:</h2>
            {analysis.conditions.length > 0 ? (
              analysis.conditions.map((condition, index) => (
                <Card key={index} className="mb-4">
                  <CardHeader>
                    <CardTitle>{condition.conditionName}</CardTitle>
                    <CardDescription>Confidence: {(condition.confidence * 100).toFixed(2)}%</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-2">
                      <strong>First Aid Advice:</strong> {condition.firstAidAdvice}
                    </p>
                    {condition.medicineRecommendations.length > 0 && (
                      <p className="mb-2">
                        <strong>Medicine Recommendations:</strong> {condition.medicineRecommendations.join(', ')}
                      </p>
                    )}
                    {condition.resourceUrl && (
                      <a
                        href={condition.resourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-accent hover:underline"
                      >
                        Learn More
                      </a>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <p>No conditions found based on the symptoms provided.</p>
            )}

            {analysis.tips.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mt-4 mb-2">General Health Tips:</h3>
                <ul className="list-disc list-inside">
                  {analysis.tips.map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Medical Disclaimer */}
        <p className="text-sm text-muted-foreground mt-4 text-center">
          <strong>Disclaimer:</strong> This app provides suggestions only and should not replace professional medical
          advice. Always consult with a qualified healthcare provider for diagnosis and treatment.
        </p>
      </div>
      <Toaster />
    </div>
  );
}
